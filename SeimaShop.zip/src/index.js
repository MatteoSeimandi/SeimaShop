import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap/dist/css/bootstrap.min.css';		// obbligatorio
import './index.css';
import Main from './main';

ReactDOM.render( <Main />, document.getElementById('root'));
